#pragma once

class MyVector;
class MyMatrixCRS;
class mesh;

void run(string const& ConfigFile);

void InterpretConfigFile(string const& ConfigFile,
                         string& InMeshFile, string& OutMeshFile,
                         unsigned& MaxIter, double& Tol);
