/**
* @file main.cpp
*/

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

#include "MyVector.h"
#include "MyMatrixCRS.h"
#include "mesh.h"
#include "tools.h"
#include "mesh_improvement.h"
#include "run.h"



int main(int argc, char** argv)
{
   if (argc == 2)
   {
      string const ConfigFile = argv[1];
      run(ConfigFile);
   }
   else
   {
      cout << "Usage: pass CONFIGFILE as command line argument." << endl << endl;


      mesh mymesh;
      mymesh.test_init();

   //   mymesh.WriteToPlot("MyMesh0.dat");

      mesh out_mesh = ImproveMesh(mymesh, 1e-5, 3);
   //   MyMatrixCRS Ml, Mr;
   //   MyVector diag;
   //   mymesh.computeConnectivityMatrices(Ml, Mr, diag);
   //
   //   ImproveMeshOneStep(mymesh, Ml, Mr, diag);
   //   vector<uint32_t> FlippedNodes;
   //   mymesh.CheckElements(FlippedNodes);
   //
   //   mesh prev; prev.test_init();
   //   ImproveStep(prev, mymesh, FlippedNodes);

   //   int dummy; cin >> dummy;
   //   out_mesh.WriteToPlot("MyMesh1.dat");
   //   out_mesh.CheckElements(FlippedNodes);



   //
   //   mesh H5 = ReadMeshFromHaase("coords_2d.txt", "elements_2d.txt");
   //   cout << H5._xCoords << endl;
   ////
   //   H5.WriteToBinary("Haase_100x200.dat");
   //
   //   mesh H5_; H5_.ReadFromBinary("Haase_5x5.dat");
   //
   //   cout << H5_._yCoords << endl;
   //   cout << H5_.getTopology() << endl;


   }
   return 0;
}

















