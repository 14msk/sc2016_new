/** @file mesh.cpp
*   @author Simon Pieber, Pia Kedl
*   @date SoSe 2016
*/

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cassert>
#include <algorithm>
#include <cmath>

using namespace std;

#include "MyVector.h"
#include "MyMatrixCRS.h"
#include "mesh.h"
#include "tools.h"

void mesh::test_init()
{
//   MyVector x{-0.2,   1,     2, 0.5, 0.2, 0.5, 1.6, 0.5},
//            y{   0, 0.1,   1.2,   1,   1,   2, 4.3, 0.5};
//   _xCoords = x; _yCoords = y;
//
//   vector<uint32_t> t{0,1,7, 1,4,7, 0,7,4, 1,2,3, 2,6,3, 3,6,5, 3,5,4, 1,3,4};
//   _Topology = t;

   MyVector x{-1.2,   1,     2, 1.3, -0.5, 0.5, 1.6, 0.5, 2.7, 2.8, 1.1},
            y{  -1, 0.1,   1.2, 0.8,    2, 2, 4.3, 0.5, 3, 1, -0.4};
   _xCoords = x; _yCoords = y;

   vector<uint32_t> t{0,1,7, 1,4,7, 0,7,4, 1,2,3, 2,6,3, 3,6,5, 3,5,4, 1,3,4, 2,8,6, 9,8,2, 10,9,2,
                      10,2,1, 0,10,1};
   _Topology = t;

}

vector<bool> mesh::getInteriourNodes() const
{
   uint32_t const NumTriangles = this->getNumTriangles();
   vector<uint32_t> Edges;

   for (uint32_t i=0; i<NumTriangles; ++i)
   {
      for (uint32_t k=0; k<3; ++k)
      {
         uint32_t N0 = _Topology[3*i + k],
                  N1 = _Topology[3*i + (k+1)%3];

         // suche Kante (N0,N1) in Edges
         uint32_t pos(-1), j(0);
         while (j<Edges.size()/2 && pos == static_cast<uint32_t>(-1))
         {
            if (    (Edges[2*j] == N0 && Edges[2*j+1] == N1)
                 || (Edges[2*j] == N1 && Edges[2*j+1] == N0) ) // gefunden
            {
               pos = 2*j;
            }
            ++j;
         }

         if (pos == static_cast<uint32_t>(-1))
         {
            Edges.push_back(N0);
            Edges.push_back(N1);
         }
         else
         {
            Edges.erase(Edges.begin()+pos, Edges.begin()+pos+2);
         }
      }
   }
   vector<bool> int_nodes(this->getNumNodes(), true);
   for (auto n : Edges)
   {
      int_nodes[n] = false;
   }
   return int_nodes;
}

void mesh::computeConnectivityMatrices(MyMatrixCRS& M_lhs, MyMatrixCRS& M_rhs, MyVector& M_rhs_diag) const
{
   uint32_t const N = this->getNumNodes();
   cout << "Bestimme innere Knoten ... ";
   vector<bool> const interiour_nodes = this->getInteriourNodes();

   {   // berechne M_rhs_diag
       MyVector tmp(N);
       for (uint32_t i=0; i<N; ++i)
       {
           if (interiour_nodes[i])  tmp[i] = 0.0;
           else                     tmp[i] = 1.0;
       }
       M_rhs_diag = tmp;
   }

   cout << "erledigt." << endl;

   cout << "Berechne System-Matrizen ... ";

   vector<uint32_t> I, J;
   vector<uint32_t> line(0); line.reserve(20);
   vector< vector<uint32_t> > graph(N, line); // zuordnung graph[i][:] indices,
                                              // welche zu i-ter zeile geheoren
   uint32_t index(0);
   for (uint32_t i=0; i<this->getNumTriangles(); ++i)
   {
      for (uint32_t k=0; k<3; ++k)
      {
         uint32_t  a = _Topology[3*i + k],
                   b = _Topology[3*i + (k+1)%3];

         if (interiour_nodes[a]) // stelle (a, b, 1) einfuegen
         {
            I.push_back(a); J.push_back(b);
            graph[a].push_back(index++);
         }
         if (interiour_nodes[b])
         {
            I.push_back(b); J.push_back(a);
            graph[b].push_back(index++);
         }
      }
   }
   // sort I,J,A wrt. line index
   vector<uint32_t> Inew(I.size()), Jnew(I.size());
   index = 0;

   for (uint32_t lineIdx=0; lineIdx<N; ++lineIdx)
   {
       for (uint32_t j=0; j<graph[lineIdx].size(); ++j)
       {
           Inew[index] = I[graph[lineIdx][j]];
           Jnew[index] = J[graph[lineIdx][j]];
           ++index;
       }
   }
//   cout << "Inew: " << Inew << endl;
//   cout << "Jnew: " << Jnew << endl;

   vector<uint32_t> nnz_vec(N+1,0);
   for (uint32_t k=0; k<N; ++k)  nnz_vec[k+1] = nnz_vec[k] + graph[k].size();
   // cout << "nnz_vec = " << nnz_vec << endl;

   // sort wrt. J
   for (uint32_t k=0; k<N; ++k)
   {
       uint32_t startIdx = nnz_vec[k],
                endIdx   = nnz_vec[k+1];
       for (uint32_t j=startIdx; j<endIdx; ++j)
       {
           for (uint32_t i=startIdx; i<endIdx-1; ++i)
           {
               if (Jnew[i] > Jnew[i+1])
                  swap(Jnew[i], Jnew[i+1]);
           }
       }
   }

   I.clear(); J.clear();
   I.reserve(Inew.size()/2); J.reserve(Inew.size()/2);

   for (uint32_t k=0; k<Inew.size()/2; ++k)
   {
       I.push_back( Inew[2*k] );
       J.push_back( Jnew[2*k] );
   }

   // berechne Ilhs, Jlhs, Irhs, Jrhs

   vector<uint32_t> Ilhs, Jlhs, Irhs, Jrhs;
   {
   uint32_t approx = I.size()/2 + 5;
   Ilhs.reserve(approx); Jlhs.reserve(approx);
   Irhs.reserve(approx); Jrhs.reserve(approx);
   }
   for (uint32_t e=0; e<I.size(); ++e)
   {
      if ( I[e] > J[e] ) // links unterhalb der diagonale
      {
         Ilhs.push_back(I[e]);
         Jlhs.push_back(J[e]);
      }
      else
      {
         Irhs.push_back(I[e]);
         Jrhs.push_back(J[e]);
      }
   }

   MyVector A(I.size(), 1.0), Alhs(Ilhs.size(), 1.0), Arhs(Irhs.size(), 1.0);
   MyMatrixCRS M_lhs_tmp(N,Ilhs,Jlhs,Alhs), M_rhs_tmp(N,Irhs,Jrhs,Arhs);

   M_lhs = M_lhs_tmp;
   M_rhs = M_rhs_tmp;

   vector<uint32_t> NumNeighbours(N);
   for (uint32_t i=0; i<N; ++i)
   {
      NumNeighbours[i] = M_lhs.getNumNonZeros(i) + M_rhs.getNumNonZeros(i);
   }

   for (size_t i=0; i<N; ++i)
   {
      if (NumNeighbours[i] != 0)
      {
         M_lhs.MultiplyRowWithScalar(i, -1.0/NumNeighbours[i] );
         M_rhs.MultiplyRowWithScalar(i,  1.0/NumNeighbours[i] );
      }
   }

   cout << "erledigt." << endl;
//   cout << "M     : " << endl; M.ShowFullMatrix();
//   cout << "M_lhs : " << endl; M_lhs.ShowFullMatrix();
//   cout << "M_rhs : " << endl; M_rhs.ShowFullMatrix();
}


void mesh::ReadFromBinary(string const& InFileName)
{
	ifstream in_file("meshes/"+InFileName, ifstream::binary);
	cout << "Lese Mesh von \"meshes/" << InFileName << "\" ... ";

   assert(in_file.good());

   uint32_t n;
   in_file.read(reinterpret_cast<char*>(&n), sizeof(uint32_t));

   _xCoords.ReadFromBinary("meshes/"+InFileName,sizeof(uint32_t));
   _yCoords.ReadFromBinary("meshes/"+InFileName,n*sizeof(double)+sizeof(uint32_t));

   uint32_t NumTris;
   in_file.seekg(4 + n*8 + n*8);
   in_file.read(reinterpret_cast<char*>(&NumTris), 4);

   uint32_t* t = new uint32_t [NumTris*3];
   in_file.read(reinterpret_cast<char*>(t), NumTris*3*4);

   _Topology.resize(NumTris*3);
   for (unsigned i=0; i<3*NumTris; ++i)
      _Topology[i] = t[i];

   delete [] t;
   cout << "erledigt. (" << this->getNumNodes() << " Knoten, " << this->getNumTriangles() << " Dreiecke)" << endl;
}

//void mesh::ReadFromBinary(string const& InFileName) {
//	InFileName = "meshes/"+InFileName;
//	ifstream in_file(InFileName, ifstream::binary);
//    uint32_t n,m;
//	if (in_file){
//
//    in_file.read(reinterpret_cast<char*>(&n), sizeof(uint32_t));
//      _xCoords.ReadFromBinary(InFileName,sizeof(uint32_t));
//      _yCoords.ReadFromBinary(InFileName,n*sizeof(double)+sizeof(uint32_t));
//      in_file.seekg(2*(_xCoords.Size()*sizeof(double))+sizeof(uint32_t));
//      in_file.read(reinterpret_cast<char*>(&m), sizeof(uint32_t));
//      _Topology.resize(m*3);
//     in_file.read(reinterpret_cast<char*>(_Topology.data()), _Topology.size()*sizeof(double));
//	}
//   return;
//}

//void mesh::WriteToBinary(string const& OutFileName) const
//{
//    OutFileName = "meshes/"+OutFileName;
//    uint32_t n = _Topology.size()/3;
//    _xCoords.WriteToBinary(OutFileName);
//    _yCoords.VectorToBinary(OutFileName);
//    ofstream out_file(OutFileName, ofstream::binary | ofstream::app);
//
//    out_file.write(reinterpret_cast<const char*>(&n), sizeof(uint32_t));
//    out_file.write(reinterpret_cast<const char*>(&_Topology[0]), 3*n* sizeof(_Topology[0]));
//    out_file.close();
//}

void mesh::WriteToBinary(string const& OutFileName) const
{
   cout << "Schreibe Mesh nach \"meshes/" << OutFileName << "\" ... ";
   ofstream OutFile("meshes/"+OutFileName, ofstream::binary);

   uint32_t const NumNodes = this->getNumNodes(),
                  NumTris  = this->getNumTriangles();
   MyVector x = _xCoords, y = _yCoords;

   OutFile.write(reinterpret_cast<char const*>(&NumNodes), 4);
   OutFile.write(reinterpret_cast<char*>(&x[0]), 8*NumNodes);
   OutFile.write(reinterpret_cast<char*>(&y[0]), 8*NumNodes);
   OutFile.write(reinterpret_cast<char const*>(&NumTris), 4);
   OutFile.write(reinterpret_cast<char const*>(&_Topology[0]), 4*3*NumTris);

   OutFile.close();
   cout << "erledigt. (" << NumNodes << " Knoten, " << NumTris << " Dreiecke)" << endl;
}


void mesh::WriteToPlot(string const& PlotFile) const
{
   string const folder = "plots/";
   string const filename = PlotFile.substr(0, PlotFile.length()-3);

   cout << "Erstelle Plotfile \"" << filename << "txt\" ... ";

   double xmin = _xCoords.getMin();
   double xmax = _xCoords.getMax();
   double ymin = _yCoords.getMin();
   double ymax = _yCoords.getMax();
   const double p = 0.05;
   xmin -= p*(xmax - xmin);
   xmax += p*(xmax - xmin);
   ymin -= p*(xmax - xmin);
   ymax += p*(xmax - xmin);

   ofstream outFile(folder+"plot_config.gp");
   outFile << "xmin=" << xmin << endl;
   outFile << "xmax=" << xmax << endl;
   outFile << "ymin=" << ymin << endl;
   outFile << "ymax=" << ymax << endl;
   outFile << "plotfile=\"" << filename << "txt\"" << endl;
   outFile << "outputfile=\"" << filename << "ps\"" << endl;
   outFile.close();

   outFile.open(folder+filename+"txt");
   for (uint32_t i=0; i<this->getNumTriangles(); ++i)
   {
      for (uint32_t k=0; k<3; ++k)
      {
         uint32_t i0 = _Topology[3*i + k],
                  i1 = _Topology[3*i + (k+1)%3];
         outFile << _xCoords.get(i0) << " " << _yCoords.get(i0) << endl;
         outFile << _xCoords.get(i1) << " " << _yCoords.get(i1) << endl;
         outFile << endl << endl;
      }
   }
   outFile.close();
   cout << "erledigt. (" << this->getNumNodes() << " Knoten, " << this->getNumTriangles() << " Dreiecke)" << endl;
}


bool mesh::CheckElements(vector<unsigned>& FlippedNodes) const
{
    FlippedNodes.clear();
    unsigned const NumTriangles = this->getNumTriangles();
    for (unsigned i=0; i<NumTriangles; ++i)
    {
        unsigned A = _Topology[3*i], B = _Topology[3*i+1], C = _Topology[3*i+2];
        double ax = _xCoords[B] - _xCoords[A], ay = _yCoords[B] - _yCoords[A],
               bx = _xCoords[C] - _xCoords[A], by = _yCoords[C] - _yCoords[A];
        double det = ax*by - bx*ay;
//        cout << "det = " << det << endl;
        if (det < 1e-7) // orientierung falsch
        {
            FlippedNodes.push_back(A);
            FlippedNodes.push_back(B);
            FlippedNodes.push_back(C);
        }
    }
    // FlippedNodes aussortieren
    sort(FlippedNodes.begin(), FlippedNodes.end());
    vector<unsigned>::iterator it = unique(FlippedNodes.begin(), FlippedNodes.end());
    FlippedNodes.resize( distance(FlippedNodes.begin(),it) );

    return FlippedNodes.size() == 0;
}

bool mesh::CheckElements() const
{
    bool mesh_is_ok(true);
    unsigned const NumTriangles = this->getNumTriangles();
    unsigned i=0;
    while (i<NumTriangles && mesh_is_ok)
    {
        unsigned A = _Topology[3*i], B = _Topology[3*i+1], C = _Topology[3*i+2];
        double ax = _xCoords[B] - _xCoords[A], ay = _yCoords[B] - _yCoords[A],
               bx = _xCoords[C] - _xCoords[A], by = _yCoords[C] - _yCoords[A];
        double det = ax*by - bx*ay;
        if (det < 1e-7) // orientierung falsch
        {
           mesh_is_ok = false;
        }
        ++i;
    }
    // FlippedNodes aussortieren

    return mesh_is_ok;
}

MyVector mesh::InnerOuterRatio(){
    MyVector InnerCircle;
    MyVector OuterCircle;
    MyVector Ratio;
    uint32_t const NumTriangles = this->getNumTriangles();
    uint32_t k1;
    uint32_t k2;
    uint32_t k3;
    MyVector v1;
    MyVector v2;
    MyVector v3;
    long double s;
    long double s1;
    long double s2;
    long double s3;

    long double InnerRadius;
    long double OuterRadius;
    long double area;

   for (uint32_t i=0; i<NumTriangles; ++i){
       k1 = _Topology[3*i];
       k2 = _Topology[3*i+1];
       k3 = _Topology[3*i+2];
       v1 = {_xCoords[k1],_yCoords[k1]};
       v2 = {_xCoords[k2],_yCoords[k2]};
       v3 = {_xCoords[k3],_yCoords[k3]};

       s1 = norm(v2-v1);
       s2 = norm(v3-v2);
       s3 = norm(v1-v3);
       s = (s1+s2+s3)/2;

       area = sqrt(s*(s-s1)*(s-s2)*(s-s3));

      InnerRadius = sqrt(((s-s1)*(s-s2)*(s-s3))/s);
      InnerCircle.PushBack(InnerRadius);

      OuterRadius = (s1*s2*s3)/(4*area);
      OuterCircle.PushBack(OuterRadius);

      Ratio.PushBack(OuterRadius/InnerRadius);
   }
   return Ratio;

   }

