#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>


using namespace std;

#include "MyVector.h"
#include "MyMatrixCRS.h"
#include "run.h"
#include "mesh.h"
#include "mesh_improvement.h"


void run(string const& ConfigFile)
{
   string InMeshFile, OutMeshFile;
   unsigned MaxIter;
   double Tol;
   InterpretConfigFile(ConfigFile, InMeshFile, OutMeshFile, MaxIter, Tol);


   mesh InMesh; InMesh.ReadFromBinary(InMeshFile);

   {
      bool mesh_is_ok = InMesh.CheckElements();
      if (!mesh_is_ok)
      {
         cout << "Eingabenetz hat Test auf falsch orientierte Elemente nicht ueberstanden!" << endl;
         assert(mesh_is_ok);
      }
   }

    MyVector b = InMesh.InnerOuterRatio();
    double sum_b = 0;
    double average_before;
      for (int i = 0; i<b.Size();i++){
        sum_b += b[i];
      }
      average_before = sum_b/b.Size();

    cout << "VORHER:\ndurchschnittliches Verhältnis Inkreisradius : Umkreisradius = 1 : " << average_before << endl;
    cout << "schlechtestes Verhältnis Inkreisradius : Umkreisradius = 1 : " << b.getMax() << endl;

   if (MaxIter == 0) // nur Plotten
   {
      InMesh.WriteToPlot(InMeshFile);
   }
   else
   {
      mesh out_mesh = ImproveMesh(InMesh, Tol, MaxIter);
      out_mesh.WriteToBinary(OutMeshFile);

      MyVector a = out_mesh.InnerOuterRatio();
    double sum_a = 0;
    double average_after;
      for (int i = 0; i<a.Size();i++){
        sum_a += a[i];
      }
      average_after = sum_a/a.Size();

    cout << "NACHHER:\ndurchschnittliches Verhältnis Inkreisradius : Umkreisradius = 1 : " << average_after << endl;
    cout << "schlechtestes Verhältnis Inkreisradius : Umkreisradius = 1 : " << a.getMax() << endl;


   }
}


void InterpretConfigFile(string const& ConfigFile,
                         string& InMeshFile, string& OutMeshFile,
                         unsigned& MaxIter, double& Tol)
{
   ifstream InFile("configfiles/" + ConfigFile);
   assert(InFile.good());

   InFile >> InMeshFile;
   InFile >> OutMeshFile;
   InFile >> MaxIter;
   if (MaxIter != 0)
      InFile >> Tol;
   InFile.close();

   if (MaxIter != 0)
   {
      cout << "Programminitialisierung mit" << endl << endl;
      cout << "  InMeshFile:    " << InMeshFile << endl;
      cout << "  OutMeshFile:   " << OutMeshFile << endl;
      cout << "  MaxIter:       " << MaxIter << endl;
      cout << "  Tol:           " << Tol << endl;
   }
   else
   {
      cout << "Plotte " << InMeshFile << " ... " <<  endl << endl;
   }


   cout << endl;
}
