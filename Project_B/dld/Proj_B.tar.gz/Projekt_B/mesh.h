#pragma once

class MyVector;
class MyMatrixCRS;

class mesh
{
public:
   /** Standardkonstruktor */
   mesh() : _xCoords(), _yCoords(), _Topology() {}

   /** Destruktor */
   ~mesh()
   {
   }

   /** Parameterkonstruktor */
   mesh(MyVector const& x, MyVector const& y, vector<uint32_t> t)
   : _xCoords(x), _yCoords(y), _Topology(t) {}

   void test_init();

   /** @return Anzahl der Knoten */
   uint32_t getNumNodes() const
   {  return _xCoords.Size();  }

   /** @return Anzahl der Dreiecke im Mesh */
   uint32_t getNumTriangles() const
   {  return _Topology.size()/3;  }

   /** Liefert Information &uuml;ber Knoten am Rand bzw. im Inneren des Gebiets.
   * @return Vektor @p v der L&auml;nge _getNumNodes(), mit
   * v[i] = true, wenn Knoten i im Inneren des Gebiets liegt.
   */
   vector<bool> getInteriourNodes() const;

   vector<uint32_t> getTopology() const { return _Topology; }

   /** Meshinitialisierung durch einlesen von Bin&auml;r-File @p InFileName
   * @param [in] InFileName Name des Files, von dem gelesen wird
   */
   void ReadFromBinary(string const& InFileName);

   /** Mesh in Bin&auml;r-File @p OutFileName schreiben
   * @param [in] InFileName Name des Files, auf das geschrieben wird
   */
   void WriteToBinary(string const& OutFileName) const;

   /** Schreibe Textfile zum einlesen in Gnuplot Skript
   * @param [in] OutFileName File Name
   * @warning Ecken kommen teilweise doppelt vor, Knoten teilweise bis zu vier mal.
   */
   void WriteToPlot(string const& OutFileName) const;

   /** @todo Dokumentation
   */
   void computeConnectivityMatrices(MyMatrixCRS& M_lhs, MyMatrixCRS& M_rhs, MyVector& M_rhs_diag) const;

   bool CheckElements(vector<unsigned>& FlippedNodes) const;
   bool CheckElements() const;
   MyVector InnerOuterRatio();


   MyVector _xCoords;               /*!< x Knotenkoordinaten */
   MyVector _yCoords;               /*!< y Knotenkoordinaten */

private:

   vector<uint32_t> _Topology;      /*!< Netzaufbau: Je 3 Werte definieren ein Dreieck
                                         (Array mit 3*_NumTriangles Elementen) */
};
