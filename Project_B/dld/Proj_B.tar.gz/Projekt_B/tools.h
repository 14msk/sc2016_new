#ifndef TOOLS_H_INCLUDED
#define TOOLS_H_INCLUDED

class MyVector;
class MyMatrixCRS;
class mesh;

/** L&ouml;sen von Ax = b mit Dreiecksmatrix A.
*   @param [in] @p A quadratische, strikt (!) obere Dreiecksmatrix. Es wird implizit
*   angenommen, dass die Hauptdiagonale von @p A aus lauter 1en besteht.
*   @param [in] b rechte Seite
*/
MyVector ForwardSubstitutionImplicitOneDiag(MyMatrixCRS const& A, MyVector const& b);

mesh ReadMeshFromHaase(string const& FileCoords, string const& FileElements);


template <class T>
ostream& operator<<(ostream& s, vector<T> const& v)
{
   s << v.size() << ": ";
   for (T vi : v)
      s << vi << " ";
   return s;
}


#endif // TOOLS_H_INCLUDED
