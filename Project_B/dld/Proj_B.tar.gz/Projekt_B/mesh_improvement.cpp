/** @file mesh_improvement.cpp
*   @author Simon Pieber, Pia Kedl
*   @date SoSe 2016
*/

#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

#include "MyVector.h"
#include "MyMatrixCRS.h"
#include "mesh.h"
#include "mesh_improvement.h"
#include "tools.h"

mesh ImproveMesh(mesh const& in_mesh, double TOL, uint32_t MAX_ITER)
{
   MyMatrixCRS M_lhs, M_rhs;
   MyVector M_rhs_diag;
   in_mesh.computeConnectivityMatrices(M_lhs, M_rhs, M_rhs_diag);

   cout << "Starte Netzverbesserung ... " << endl;
   mesh PreviousMesh(in_mesh), NewMesh(in_mesh);
   double change; uint32_t iter(0); vector<unsigned> FlippedNodes;
   bool last_iteration(false);
   do
   {
      ImproveMeshOneStep(NewMesh, M_lhs, M_rhs, M_rhs_diag);

      if (! NewMesh.CheckElements(FlippedNodes))
      {
         // NewMesh.WriteToPlot("MyMesh_err.txt");
          ImproveStep(PreviousMesh, NewMesh, FlippedNodes);
//          ImproveStep(PreviousMesh, NewMesh);

          if ( ! NewMesh.CheckElements() )
          {
              ImproveStep(PreviousMesh, NewMesh);
          }
          last_iteration = true;
      }

      if (! NewMesh.CheckElements() )
      {
         NewMesh._xCoords = PreviousMesh._xCoords;
         NewMesh._yCoords = PreviousMesh._yCoords;
         cout << "WARNUNG: Algorithmus stoppt wegen umkippender Elemente! " << endl;
         change = 0;
      }
      else
      {
         change = computeChangeInMeshes(PreviousMesh, NewMesh);
         cout << "Knotenverschiebungen in Schritt " << iter+1 << ": " << change << endl;
         PreviousMesh = NewMesh;
         ++iter;
      }
   }
   while (change > TOL && iter < MAX_ITER && !last_iteration);
   cout << "Netzverbesserung abgeschlossen." << endl;
   return NewMesh;
}

void ImproveStep(mesh const& PreviousMesh, mesh& NewMesh, vector<uint32_t> const& FlippedNodes)
{
   cout << "WARNUNG: Umkippende Elemente. Versuche assoziierte kippende Knoten passend zu verschieben..." << endl;
   double lambda, lambda0(-1.0), lambda1(-1.0);
   MyVector const x_new(NewMesh._xCoords),
                  y_new(NewMesh._yCoords);
   bool b(false), b_previous(false);

   for (lambda = 0; lambda < 2.0 && (lambda0<0.0 || lambda1<0.0); lambda += 0.025) //  && lambda0<0.0 && lambda1<0.0
   {
      for (int i=0; i<FlippedNodes.size(); ++i)
      {
          uint32_t node = FlippedNodes[i];
          NewMesh._xCoords[node] = (1.0-lambda)*x_new[node] + lambda*PreviousMesh._xCoords[node];
          NewMesh._yCoords[node] = (1.0-lambda)*y_new[node] + lambda*PreviousMesh._yCoords[node];
      }
      b = NewMesh.CheckElements();

      if       (b  && !b_previous)  lambda0 = lambda;
      else if  (!b &&  b_previous)  lambda1 = lambda;

      b_previous = b;
//      cout << "lambda: " << lambda << "  --  " << b << endl;
   }
//   cout << "lambda 0/1: " << lambda0 << " " << lambda1 << endl;

   if (lambda0>0 && lambda1>0)
   {
      lambda = (lambda0 + lambda1)/2.0;
      cout << "... erfolgreich mit lambda = " << lambda << endl;
   }
   else
   {
      lambda = 0;
      cout << "... erfolglos" << endl;
   }
   for (int i=0; i<FlippedNodes.size(); ++i)
   {
       uint32_t node = FlippedNodes[i];
       NewMesh._xCoords[node] = (1.0-lambda)*x_new[node] + lambda*PreviousMesh._xCoords[node];
       NewMesh._yCoords[node] = (1.0-lambda)*y_new[node] + lambda*PreviousMesh._yCoords[node];
   }
   return;
}

void ImproveStep(mesh const& PreviousMesh, mesh& NewMesh)
{
   cout << "WARNUNG: Umkippende Elemente. Versuche gesamtes Netz passend zu verschieben..." << endl;
   double lambda, lambda0(-1.0), lambda1(-1.0);
   MyVector const x_new(NewMesh._xCoords),
                  y_new(NewMesh._yCoords);
   bool b(false), b_previous(false);
   unsigned const N = NewMesh.getNumNodes();
   for (lambda = 0; lambda < 2.0 && (lambda0<0.0 || lambda1<0.0); lambda += 0.025) //  && lambda0<0.0 && lambda1<0.0
   {
      for (int i=0; i<N; ++i)
      {
          NewMesh._xCoords[i] = (1.0-lambda)*x_new[i] + lambda*PreviousMesh._xCoords[i];
          NewMesh._yCoords[i] = (1.0-lambda)*y_new[i] + lambda*PreviousMesh._yCoords[i];
      }
      b = NewMesh.CheckElements();

      if       (b  && !b_previous)  lambda0 = lambda;
      else if  (!b &&  b_previous)  lambda1 = lambda;

      b_previous = b;
//      cout << "lambda: " << lambda << "  --  " << b << endl;
   }
//   cout << "lambda 0/1: " << lambda0 << " " << lambda1 << endl;
   if (lambda0>0 && lambda1>0)
   {
      lambda = (lambda0 + lambda1)/2.0;
      cout << "... erfolgreich mit lambda = " << lambda << endl;
   }
   else
   {
      lambda = 0;
      cout << "... erfolglos" << endl;
   }
   for (int i=0; i<N; ++i)
   {
       NewMesh._xCoords[i] = (1.0-lambda)*x_new[i] + lambda*PreviousMesh._xCoords[i];
       NewMesh._yCoords[i] = (1.0-lambda)*y_new[i] + lambda*PreviousMesh._yCoords[i];
   }
   return;
}

void ImproveMeshOneStep(mesh& in_mesh, MyMatrixCRS const& M_lhs, MyMatrixCRS const& M_rhs, MyVector const& M_rhs_diag)
{
   MyVector bx = M_rhs*in_mesh._xCoords + in_mesh._xCoords.times(M_rhs_diag),
            by = M_rhs*in_mesh._yCoords + in_mesh._yCoords.times(M_rhs_diag);
   in_mesh._xCoords = ForwardSubstitutionImplicitOneDiag(M_lhs, bx);
   in_mesh._yCoords = ForwardSubstitutionImplicitOneDiag(M_lhs, by);
}

double computeChangeInMeshes(mesh const& m1, mesh const& m2)
{
   MyVector const DiffX = m1._xCoords - m2._xCoords,
                  DiffY = m1._yCoords - m2._yCoords;
   double const D = dot(DiffX, DiffX) + dot(DiffY, DiffY);
   return sqrt(D);
}


