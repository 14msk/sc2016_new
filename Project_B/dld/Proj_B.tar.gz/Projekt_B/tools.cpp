/** @file mesh_improvement.cpp
*   @author Simon Pieber, Pia Kedl
*   @date SoSe 2016
*/

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

#include "MyVector.h"
#include "MyMatrixCRS.h"
#include "mesh.h"
#include "tools.h"



MyVector ForwardSubstitutionImplicitOneDiag(MyMatrixCRS const& A, MyVector const& b)
{
   uint32_t const N = b.Size();
   MyVector x(N, 0.0);

   x[0] = b[0];
   for (uint32_t k=1; k<N; ++k)
   {
      x[k] = b[k] - A.dotProductWithRow(k, x);
   }

   return x;
}


mesh ReadMeshFromHaase(string const& FileCoords, string const& FileElements)
{
   ifstream inFile("meshes/"+FileCoords);

   cout << "reading coords ..." << endl;
   uint32_t NumCoords;
   inFile >> NumCoords;
   MyVector x(NumCoords), y(NumCoords);
   for (uint32_t i=0; i<NumCoords; ++i)
   {
      inFile >> x[i] >> y[i];
   }
   inFile.close();

   cout << "reading elems ..." << endl;
   inFile.open("meshes/"+FileElements);
   uint32_t NumElems;
   inFile >> NumElems;
   vector<uint32_t> elems(3*NumElems);
   for (uint32_t i=0; i<3*NumElems; ++i)
   {
      inFile >> elems[i];
   }

   cout << "reading coords ... done (" << NumCoords << " Nodes, " << NumElems << " Elements)" << endl;
   mesh mymesh(x, y, elems);
   return mymesh;
}

