##################################################################
####   Benutzung der Configfiles:  ###############################
##################################################################

                                                     z.B.
														 
1. Zeile: Dateiname des Input-Netzes (bin�r)         mesh_in.dat

2. Zeile: Dateiname des Output-Netzes                mesh_out.dat

3. Zeile: Anzahl der maximalen Iterationen           10
          (etwa 10-15 sind empfohlen)

4. Zeile: Toleranz f�r Verschiebung der              1e-4
          Knotenpunkte. Bei Unterschreitung
          dieser Toleranz wird der Algorithmus
          abgebrochen. Weitere Iterationen w�rden
          nicht mehr viel bewirken.


##################################################################

Werden Anzahl der maximalen Iterationen auf 0 gesetzt,
wird ein Plot vom Input-Netz als postscript im Ordner "plots" erzeugt.
Der Dateiname bleibt erhalten.

Die Input- und Output-Netze befinden sich im Ordner "meshes".
Bitte Dateiendung ".dat" einhalten.

Das Programm wird gestartet mit dem "run_script.sh" durch
  $ ./run_script.sh "configfile"
