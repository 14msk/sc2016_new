#!/bin/bash

if [ $# != 1 ]; then
	echo "Fehlendes Argument: configfile"
	exit
fi

make run INPUT="$1" -j8

# Soll geplottet werden?
plot_flag=`cat "configfiles/${1}" | head -n3 | tail -n1`

if [ "$plot_flag" == "0" ]; then
	plot_file=`cat "configfiles/${1}" | head -n1 | cut -d. -f1`
	cd plots
	echo "Erstelle Plot \"${plot_file}.ps\" ... "
	gnuplot plot_script.gp
	echo "Erstelle Plot \"${plot_file}.ps\" ... erledigt."
	rm -fv ${plot_file}".txt"
	cd ..
fi

