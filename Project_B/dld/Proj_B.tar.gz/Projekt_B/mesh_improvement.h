#ifndef MESH_IMPROVEMENT_H_INCLUDED
#define MESH_IMPROVEMENT_H_INCLUDED

/** Netzverbesserung mit
* @param [in] in_mesh Eingangsnetz
* @param [in] TOL
* @param [in] MAX_ITER maximale Anzahl an Iterationsn
* @return (hoffentlich) verbessertes Netz
* @warning Das resultierende Netz wird nicht &uuml;berpr&uuml;ft.
*/
mesh ImproveMesh(mesh const& in_mesh, double TOL, uint32_t MAX_ITER);

/** Netzverbesserung. (L&ouml;sen eines Gleichungssystems der Form M_lhs*x = M_rhs*b.)
* @param [in,out] in_mesh zu verbesserndes Netz
* @param [in] M_lhs linke Matrix
* @param [in] M_rhs rechte Matrix
*/
void ImproveMeshOneStep(mesh& in_mesh, MyMatrixCRS const& M_lhs, MyMatrixCRS const& M_rhs, MyVector const& M_rhs_diag);

/** Berechnet die Norm der Abst&auml;nde der Knoten.
* @param [in] m1,m2 zu vergleichende Netze
* @return Distanz
*/
double computeChangeInMeshes(mesh const& m1, mesh const& m2);

/** Versuche den Iterationsschritt geeignet zu verkleinern,
*   falls der volle Schritt zu umkippenden Elementen f&uuml;hrt.
* @param [in] PreviousMesh
* @param [in,out] NewMesh
* @param [in] FlippedNodes
*/
void ImproveStep(mesh const& PreviousMesh, mesh& NewMesh, vector<uint32_t> const& FlippedNodes);

void ImproveStep(mesh const& PreviousMesh, mesh& NewMesh);

#endif // MESH_IMPROVEMENT_H_INCLUDED
